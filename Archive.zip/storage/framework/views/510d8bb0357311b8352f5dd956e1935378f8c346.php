<header>
  <div class="header">
      <a href="#default" class="logo">CompanyLogo</a>
      <div class="header-right">
        <a class="active" href="<?php echo e(route('home')); ?>">Home</a>
        <a href="<?php echo e(route('cars')); ?>">Cars</a>
        <a href="<?php echo e(route('about')); ?>">About</a>
      </div>
    </div>
</header>
<?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/layout/header.blade.php ENDPATH**/ ?>