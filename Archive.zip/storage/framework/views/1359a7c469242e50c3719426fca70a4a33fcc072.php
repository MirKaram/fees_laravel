<footer>
    <p>Footer</p>
</footer><?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/layout/footer.blade.php ENDPATH**/ ?>