<?php $__env->startSection('content'); ?>
<br/> <h2>About page </h2><br/> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/about.blade.php ENDPATH**/ ?>