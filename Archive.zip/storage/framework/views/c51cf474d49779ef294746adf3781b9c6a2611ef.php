<?php if($authenticated): ?><?php $__env->startComponent('scribe::components.badges.base', ['colour' => "darkred", 'text' => 'requires authentication']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/vendor/knuckleswtf/scribe/src/../resources/views//components/badges/auth.blade.php ENDPATH**/ ?>