<?php $__env->startSection('content'); ?>
<h2 class="text-3xl font-bold underline">
    This is Home page
</h2>
<h1 >
    Hello world!
  </h1>
<img src="<?php echo e(asset('storage/test.png')); ?>"/>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/index.blade.php ENDPATH**/ ?>