<!DOCTYPE html>
<html>
    <head>
        <title>Test Page</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" >
        <!-- <link href="/dist/output.css" rel="stylesheet"> -->
    </head>
<body >
    <p><?php echo e(asset('css/app.css')); ?></p>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
</html>
<?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/layout/app.blade.php ENDPATH**/ ?>