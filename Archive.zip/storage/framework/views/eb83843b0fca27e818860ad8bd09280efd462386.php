<?php $__env->startSection('content'); ?>
    <div class="m-auto w-4/5 py-24">
        <div class="text-center">
            <h2 class="text-5xl uppercase bold">
                This is car Page
            </h2>
            <p class="text-ml italic">
                Total = <?php echo e($cars->count()); ?> cars
            </p>
        </div>

        <div class="pt-10">
            <a href="cars/create" class="border-b-2 pb-2 border-dotted italic text-gray-500">
                Add new carr&rarr;
            </a>
        </div>
        <div class="w-5/6 py-10">
           <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="m-auto">
            <span class="uppercase text-blue-500 font-bold text-xs italic">
                Founded: <?php echo e($item->founded); ?>

            </span>
            <h2 class="text-5xl text-gray-500">
                <?php echo e($item->name); ?>

            </h2>
            <p class="text-lg text-gray-700 py-6">
                <?php echo e($item->description); ?>

            </p>
            <hr class="mt-4 mb-8">
        </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/disk_1/laravel_workspace/testWebApp/resources/views/cars/index.blade.php ENDPATH**/ ?>