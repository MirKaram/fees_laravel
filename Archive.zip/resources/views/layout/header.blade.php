<header>
  <div class="header">
      <a href="#default" class="logo">CompanyLogo</a>
      <div class="header-right">
        <a class="active" href="{{ route('home') }}">Home</a>
        <a href="{{ route('cars') }}">Cars</a>
        <a href="{{ route('about') }}">About</a>
      </div>
    </div>
</header>
