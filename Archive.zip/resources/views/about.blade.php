
@extends('layout.app')
@section('content')
<br/> <h2>About page </h2><br/> 
@endsection
