@extends('layout.app')
@section('content')
<h2 class="text-3xl font-bold underline">
    This is Home page
</h2>
<h1 >
    Hello world!
  </h1>
<img src="{{ asset('storage/test.png') }}"/>
@endsection


